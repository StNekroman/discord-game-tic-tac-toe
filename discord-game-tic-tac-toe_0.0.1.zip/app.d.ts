import { DiscordApi, GameEvent, GamePluginEntryPoint, GameUser, MessageDescriptor, Serializable } from "discord-text-games-api";
interface SaveBundle {
    started: boolean;
    stale: boolean;
    channelId: string;
    gameBoardMessageDescriptor?: MessageDescriptor;
    currentPlayerIndex?: 0 | 1;
    lastTurnMessageId?: string;
    acceptSelection: boolean;
    possibleTurnsCount: number;
    gameSize: number;
    players: GameUser[];
    boardStates: (0 | 1 | undefined)[][];
    playerIcons: {
        0: string;
        1: string;
    };
}
export default class TicTacToe implements GamePluginEntryPoint<SaveBundle> {
    private static readonly LEAVE_BUTTON;
    discordApi: DiscordApi;
    private state;
    private readonly gameSize;
    private readonly playerIcons;
    constructor(args?: string);
    initialize(saveBundle?: SaveBundle): Promise<void>;
    destroy(): Promise<Serializable<SaveBundle> | void>;
    onEvent(event: GameEvent): void;
    private handleJoin;
    private handleLeave;
    private startGame;
    private sendTurnNotification;
    private getCellIcon;
    private buildTicTacToe;
    private buildButton;
    private handleButtonClick;
    private getCoordFromIndex;
    private handleUserTurn;
    private endGameDraw;
    private checkForWin;
    private renderWinMessage;
}
export {};
